// CLASSE E HERENÇA - CONTA
class Conta {
    constructor(nomeCorrentista, banco, numeroConta, saldo) {
        this._nomeCorrentista = nomeCorrentista;
        this._banco = banco;
        this._numeroConta = numeroConta;
        this._saldo = saldo;
    }

    setNomeCorrentista(n) {
        this._nomeCorrentista = n;
    }
    getNomeCorrentista() {
        return this._nomeCorrentista;
    }
    setBanco(b) {
        this._banco = b;
    }
    getBanco() {
        return this._banco;
    }
    setNumeroConta(c) {
        this._numeroConta = c;
    }
    getNumeroConta() {
        return this._numeroConta;
    }
    setSaldo(s) {
        this._saldo = s;
    }
    getSaldo() {
        return this._saldo;
    }
}

// CLASSE CORRENTE - HERDA HERANÇA DE CONTA
class Corrente extends Conta {
    constructor(nomeCorrentista, banco, numeroConta, saldo, saldoEspecial) {
        super(nomeCorrentista, banco, numeroConta, saldo);
        this._saldoEspecial = saldoEspecial;
    }
    setSaldoEspecial(se) {
        this._saldoEspecial = se;
    }
    getSaldoEspecial() {
        return this._saldoEspecial;
    }
}

// CLASSE POUPANÇA - HERDA HERANÇA DE CONTA
class Poupanca extends Conta {
    constructor(nomeCorrentista, banco, numeroConta, saldo, juros, dataVencimento) {
        super(nomeCorrentista, banco, numeroConta, saldo);
        this._juros = juros;
        this._dataVencimento = dataVencimento;
    }
    setJuros(j) {
        this._juros = j;
    }
    getJuros() {
        return this._juros
    }
    setDataVencimento(dt) {
        this._dataVencimento = dt;
    }
    getDataVencimento() {
        return this._dataVencimento;
    }
}

// RECEBENDO DADOS PELO PROMPT:
let nome = prompt("Nome do correntista: ");
let banco = prompt("Banco: ");
let numeroConta = prompt("Número da conta: ");
let saldo = parseFloat(prompt("Saldo: "));
let saldoEsp = parseFloat(prompt("Saldo especial da conta corrente: "));
let juros = parseFloat(prompt("Juros da poupança: "));
let dataVenc = prompt("Data de vencimento da poupança: ");
 
// OBJETOS DAS CLASSES
let contaCorrente = new Corrente(nome, banco, numeroConta, saldo, saldoEsp);
let contaPoupanca = new Poupanca(nome, banco, numeroConta, saldo, juros, dataVenc);
 
// RESULTADOS
alert(`Conta Corrente:
Nome: ${contaCorrente.nomeCorrentista}
Banco: ${contaCorrente.banco}
Número: ${contaCorrente.numeroConta}
Saldo: ${contaCorrente.saldo}
Saldo Especial: ${contaCorrente.saldoEspecial}`);
 
alert(`Conta Poupança:
    Nome: ${contaPoupanca.nomeCorrentista}
    Banco: ${contaPoupanca.banco}
    Número: ${contaPoupanca.numeroConta}
    Saldo: ${contaPoupanca.saldo}
    Juros: ${contaPoupanca.juros}
    Data de Vencimento: ${contaPoupanca.dataVencimento}`);
// FUNÇÃO CONSTRUTORA - CALCULAR ÁREA DO RETÂNGULO:
function Retangulo(base, altura) {
    this.base = base;
    this.altura = altura;

    this.calculaArea = function() {
        return(this.base * this.altura);
    }
}

// CHAMAR PELO BOTÃO:
function calcularArea() {
    let base = parseFloat(document.getElementById("base").value);
    let altura = parseFloat(document.getElementById("altura").value);

    let retangulo = new Retangulo(base, altura);
    let area = retangulo.calculaArea();
 
    document.getElementById("resultado").innerHTML =`Base: ${retangulo.base} <br> Altura: ${retangulo.altura} <br> Área do Retângulo: ${area}`;
}
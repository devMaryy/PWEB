let texto = "Bom dia, Boa Tarde, Boa Noite!"; 
module.exports = texto; 

// EXEMPLO 1

console.log("Primeiro exemplo");